import os
import base64
import json
import jinja2
import urllib.parse
from short import shorten_url

from dbSettings.dbConnectDisconnect import dbConnection as dbConnection
from dbSettings.dbConnectDisconnect import dbDisconnect as dbDisconnect

def render_error():
    with open('error.html') as f:
        template = jinja2.Template(f.read())
        
    html = template.render(url=os.getenv("LAMBDA_URL"))

    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'text/html'
        },
        'body': html
    }


def lambda_handler(event, context):
    print("EVENT", event)
    
    try:
        # Establishing DB Connection
        con, cursor = dbConnection()
        
        # Getting http context from lambda event
        http = event["requestContext"]["http"]

        if http['method'] == 'GET' and http['path'] == '/':
            with open('index.html') as f:
                template = jinja2.Template(f.read())
            html = template.render()
            return {
                'statusCode': 200,
                'headers': {
                    'Content-Type': 'text/html'
                },
                'body': html
            }
        
        
        if http['method'] == 'GET' and not http['path'] == '/':
            short = http["path"][1:]
            query = """SELECT original FROM kLinks WHERE short=%s;"""
            cursor.execute(query, (short, ), )
            
            if cursor.rowcount == 1:
                original = cursor.fetchone()
                print(original)
                
                response = {
                        'statusCode': 301,
                        'headers': {
                            'Location': original[0]
                        }
                    }
                    
                return response
            else:
                return render_error()
            
            
        if http['method'] == 'POST':
            body = base64.b64decode(event["body"]).decode('utf-8')

            if 'url' in body:
                url = urllib.parse.unquote(body.split("url=")[1].strip())
                short, code = shorten_url(url)
                query = """INSERT INTO kLinks (original, short) 
                            VALUES (%s, %s)
                            ON CONFLICT (original, short) DO NOTHING;
                            """
                cursor.execute(query, (url, code, ), )
                con.commit()
                
                with open('success.html') as f:
                    template = jinja2.Template(f.read())
            
                html = template.render(url=short)
            
                return {
                    'statusCode': 200,
                    'headers': {
                        'Content-Type': 'text/html'
                    },
                    'body': html
                }
                
            else:
                return render_error()
        else:
            return render_error()
    
    except Exception as error:
        print("lambda_handler: Error Occured", error)
        return render_error()
        
    finally:
        if con and cursor:
            dbDisconnect(con, cursor)
            print("Finally All things closed")
