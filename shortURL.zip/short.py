import os
import hashlib
import base64

def shorten_url(long_url):
    # Hash the long URL using SHA256
    hashed_url = hashlib.sha256(long_url.encode()).digest()

    # Base64 encode the hashed URL to generate a short code
    short_code = base64.urlsafe_b64encode(hashed_url)[:7].decode()

    # Build the shortened URL by appending the short code to a base URL
    base_url = os.getenv("LAMBDA_URL")
    shortened_url = base_url + short_code

    return shortened_url, short_code
